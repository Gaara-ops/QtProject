#include <iostream>
using namespace std;
//分析通分后两个分数相减的结果函数
int getResult(int molecule,int denominator){
    if(molecule == 0){
        return 0;
    }else if(molecule >0 && denominator >0){
        return 1;
    }else if(molecule >0 && denominator <0){
        return -1;
    }else if(molecule <0 && denominator >0){
        return -1;
    }else if(molecule <0 && denominator <0){
        return 1;
    }
}

//a1表示第一个数的分子,a2表示第一个数的分母
//b1表示第二个数的分子,b2表示第二个数的分母
//-1表示a1<a2;0表示a1=a2;1表示a1>a2;
int compare(int a1,int a2,int b1,int b2){
    if(a2==0 || b2==0){
        return -10;
    }
    //分母相等
    if(a2 == b2){
        int molecule = a1-b1;
        return getResult(molecule,a2);
    }
    //分母不相等
    int denominator = a2*b2;
    int tmp1 = a1*b2;
    int tmp2 = b1*a2;
    int molecule = tmp1-tmp2;
    return getResult(molecule,denominator);
}

int main()
{
    //a11存储第一个分数的分子,a12存储第一个分数的分母
    int a11 = 0,a12 = 1;
    //a21存储第二个分数的分子,a22存储第二个分数的分母
    int a21 = 0,a22 = 1;
    cout << "input '0 0' to exit!" << endl;
    while(1){
        cout << "please a1:";//输入第一个分数
        cin >> a11 >> a12;
        //如果输入的分子和分母均为0则退出
        if(a11 ==0 && a12 ==0){
            break;
        }
        cout << "please a2:";//输入第二个分数
        cin >> a21 >> a22;
        //如果输入的分子和分母均为0则退出
        if(a21 ==0 && a22 ==0){
            break;
        }
        //调用比较函数比较两个分数的大小
        int res = compare(a11,a12,a21,a22);
        //判断两个分数的大小;0表示相等,1表示第一个分数大,-1表示第一个数小
        if(res == 0){
            cout << "res: a1=a2" << endl;
        }else if(res == 1){
            cout << "res: a1>a2" << endl;
        }else if(res == -1){
            cout << "res: a1<a2"  << endl;
        }else{
            cout << "error: denominator is zero!"  << endl;
        }
    }

    return 0;
}
